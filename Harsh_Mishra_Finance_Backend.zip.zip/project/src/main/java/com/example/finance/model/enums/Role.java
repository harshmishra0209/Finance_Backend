package com.example.finance.model.enums;

public enum Role {
    VIEWER,
    ANALYST,
    ADMIN
}
