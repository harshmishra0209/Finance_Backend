package com.example.finance.service;

import com.example.finance.dto.FinancialRecordDto;
import com.example.finance.exception.ResourceNotFoundException;
import com.example.finance.model.FinancialRecord;
import com.example.finance.model.User;
import com.example.finance.model.enums.RecordType;
import com.example.finance.repository.FinancialRecordRepository;
import com.example.finance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class FinancialRecordService {

    @Autowired
    private FinancialRecordRepository recordRepository;

    @Autowired
    private UserRepository userRepository;

    public FinancialRecord createRecord(FinancialRecordDto dto, String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        FinancialRecord record = new FinancialRecord();
        record.setAmount(dto.getAmount());
        record.setType(dto.getType());
        record.setCategory(dto.getCategory());
        record.setDate(dto.getDate());
        record.setNotes(dto.getNotes());
        record.setUser(user);

        return recordRepository.save(record);
    }

    public Page<FinancialRecord> getAllRecords(Pageable pageable) {
        return recordRepository.findAll(pageable);
    }

    public Page<FinancialRecord> getFilteredRecords(RecordType type, String category, Pageable pageable) {
        return recordRepository.findByTypeAndCategory(type, category, pageable);
    }

    public FinancialRecord getRecordById(Long id) {
        return recordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Record not found with id: " + id));
    }

    public FinancialRecord updateRecord(Long id, FinancialRecordDto dto) {
        FinancialRecord record = getRecordById(id);
        
        record.setAmount(dto.getAmount());
        record.setType(dto.getType());
        record.setCategory(dto.getCategory());
        record.setDate(dto.getDate());
        record.setNotes(dto.getNotes());

        return recordRepository.save(record);
    }

    public void deleteRecord(Long id) {
        FinancialRecord record = getRecordById(id);
        recordRepository.delete(record);
    }
}
