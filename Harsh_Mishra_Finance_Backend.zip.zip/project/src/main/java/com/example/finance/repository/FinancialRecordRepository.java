package com.example.finance.repository;

import com.example.finance.model.FinancialRecord;
import com.example.finance.model.enums.RecordType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface FinancialRecordRepository extends JpaRepository<FinancialRecord, Long> {

    Page<FinancialRecord> findByUserId(Long userId, Pageable pageable);
    
    // For admins to filter records
    @Query("SELECT f FROM FinancialRecord f WHERE (:type IS NULL OR f.type = :type) AND (:category IS NULL OR f.category = :category)")
    Page<FinancialRecord> findByTypeAndCategory(@org.springframework.data.repository.query.Param("type") RecordType type, @org.springframework.data.repository.query.Param("category") String category, Pageable pageable);

    // Queries for dashboard summaries
    @Query("SELECT SUM(f.amount) FROM FinancialRecord f WHERE f.type = 'INCOME'")
    BigDecimal getTotalIncome();

    @Query("SELECT SUM(f.amount) FROM FinancialRecord f WHERE f.type = 'EXPENSE'")
    BigDecimal getTotalExpenses();

    // Find recent activity
    List<FinancialRecord> findTop5ByOrderByDateDesc();

    @Query("SELECT f.category as category, SUM(f.amount) as totalAmount FROM FinancialRecord f WHERE f.type = 'EXPENSE' GROUP BY f.category")
    List<com.example.finance.dto.CategoryTotalProjection> getCategoryTotals();

    @Query(value = "SELECT DATE_FORMAT(date, '%Y-%m') as month, " +
            "SUM(CASE WHEN type = 'INCOME' THEN amount ELSE 0 END) as totalIncome, " +
            "SUM(CASE WHEN type = 'EXPENSE' THEN amount ELSE 0 END) as totalExpense " +
            "FROM financial_records GROUP BY DATE_FORMAT(date, '%Y-%m') ORDER BY month", nativeQuery = true)
    List<com.example.finance.dto.MonthlyTrendProjection> getMonthlyTrend();
}
