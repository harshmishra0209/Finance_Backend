package com.example.finance.controller;

import com.example.finance.dto.FinancialRecordDto;
import com.example.finance.model.FinancialRecord;
import com.example.finance.model.enums.RecordType;
import com.example.finance.service.FinancialRecordService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.example.finance.dto.ApiResponse;

@RestController
@RequestMapping("/api/records")
public class FinancialRecordController {

    @Autowired
    private FinancialRecordService recordService;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<FinancialRecord>> createRecord(@Valid @RequestBody FinancialRecordDto dto, Authentication authentication) {
        FinancialRecord record = recordService.createRecord(dto, authentication.getName());
        return new ResponseEntity<>(new ApiResponse<>("Record created successfully", record), HttpStatus.CREATED);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'VIEWER')")
    public ResponseEntity<ApiResponse<Page<FinancialRecord>>> getRecords(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) RecordType type,
            @RequestParam(required = false) String category) {

        Page<FinancialRecord> records = recordService.getFilteredRecords(type, category, PageRequest.of(page, size));
        return ResponseEntity.ok(new ApiResponse<>("Records fetched successfully", records));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'VIEWER')")
    public ResponseEntity<ApiResponse<FinancialRecord>> getRecordById(@PathVariable Long id) {
        return ResponseEntity.ok(new ApiResponse<>("Record fetched successfully", recordService.getRecordById(id)));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<FinancialRecord>> updateRecord(@PathVariable Long id, @Valid @RequestBody FinancialRecordDto dto) {
        return ResponseEntity.ok(new ApiResponse<>("Record updated successfully", recordService.updateRecord(id, dto)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteRecord(@PathVariable Long id) {
        recordService.deleteRecord(id);
        return ResponseEntity.ok(new ApiResponse<>("Record deleted successfully", null));
    }
}
