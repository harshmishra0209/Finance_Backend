package com.example.finance.dto;

import java.math.BigDecimal;

public interface MonthlyTrendProjection {
    String getMonth();
    BigDecimal getTotalIncome();
    BigDecimal getTotalExpense();
}
