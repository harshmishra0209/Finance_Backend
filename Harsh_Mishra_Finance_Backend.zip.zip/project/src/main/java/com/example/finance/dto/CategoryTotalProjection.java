package com.example.finance.dto;

import java.math.BigDecimal;

public interface CategoryTotalProjection {
    String getCategory();
    BigDecimal getTotalAmount();
}
