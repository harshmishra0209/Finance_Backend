package com.example.finance.controller;

import com.example.finance.dto.AuthRequest;
import com.example.finance.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.finance.dto.AuthResponse;
import com.example.finance.dto.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> authenticateUser(@Valid @RequestBody AuthRequest authRequest) {
        return ResponseEntity.ok(new ApiResponse<>("Authentication successful", authService.authenticateUser(authRequest)));
    }
}
