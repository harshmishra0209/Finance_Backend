package com.example.finance.service;

import com.example.finance.dto.CategoryTotalProjection;
import com.example.finance.dto.DashboardSummaryDto;
import com.example.finance.dto.MonthlyTrendProjection;
import com.example.finance.model.FinancialRecord;
import com.example.finance.repository.FinancialRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class DashboardService {

    @Autowired
    private FinancialRecordRepository recordRepository;

    public DashboardSummaryDto getSummary() {
        BigDecimal totalIncome = recordRepository.getTotalIncome();
        if (totalIncome == null) totalIncome = BigDecimal.ZERO;

        BigDecimal totalExpenses = recordRepository.getTotalExpenses();
        if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;

        BigDecimal netBalance = totalIncome.subtract(totalExpenses);

        List<FinancialRecord> recentActivity = recordRepository.findTop5ByOrderByDateDesc();

        return new DashboardSummaryDto(totalIncome, totalExpenses, netBalance, recentActivity);
    }

    public List<CategoryTotalProjection> getCategoryTotals() {
        return recordRepository.getCategoryTotals();
    }

    public List<MonthlyTrendProjection> getMonthlyTrend() {
        return recordRepository.getMonthlyTrend();
    }
}
