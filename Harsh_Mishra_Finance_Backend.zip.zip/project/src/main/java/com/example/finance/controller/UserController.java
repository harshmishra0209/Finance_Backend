package com.example.finance.controller;

import com.example.finance.dto.RegisterRequest;
import com.example.finance.model.User;
import com.example.finance.model.enums.Role;
import com.example.finance.model.enums.UserStatus;
import com.example.finance.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.example.finance.dto.ApiResponse;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@PreAuthorize("hasRole('ADMIN')")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<ApiResponse<User>> createUser(@Valid @RequestBody RegisterRequest registerRequest) {
        User createdUser = userService.createUser(registerRequest);
        return new ResponseEntity<>(new ApiResponse<>("User created successfully", createdUser), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<User>>> getAllUsers() {
        return ResponseEntity.ok(new ApiResponse<>("Users retrieved successfully", userService.getAllUsers()));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<ApiResponse<User>> updateUserStatus(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String statusStr = body.get("status");
        if (statusStr == null) {
            throw new IllegalArgumentException("status field is required");
        }
        UserStatus status = UserStatus.valueOf(statusStr.toUpperCase());
        return ResponseEntity.ok(new ApiResponse<>("User status updated successfully", userService.changeUserStatus(id, status)));
    }

    @PutMapping("/{id}/role")
    public ResponseEntity<ApiResponse<User>> updateUserRole(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String roleStr = body.get("role");
        if (roleStr == null) {
            throw new IllegalArgumentException("role field is required");
        }
        Role role = Role.valueOf(roleStr.toUpperCase());
        return ResponseEntity.ok(new ApiResponse<>("User role updated successfully", userService.changeUserRole(id, role)));
    }
}
