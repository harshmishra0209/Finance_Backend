package com.example.finance.controller;

import com.example.finance.dto.CategoryTotalProjection;
import com.example.finance.dto.DashboardSummaryDto;
import com.example.finance.dto.MonthlyTrendProjection;
import com.example.finance.dto.ApiResponse;
import com.example.finance.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("hasAnyRole('ADMIN', 'ANALYST', 'VIEWER')")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/summary")
    public ResponseEntity<ApiResponse<DashboardSummaryDto>> getSummary() {
        return ResponseEntity.ok(new ApiResponse<>("Dashboard summary fetched successfully", dashboardService.getSummary()));
    }

    @GetMapping("/category-totals")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    public ResponseEntity<ApiResponse<List<CategoryTotalProjection>>> getCategoryTotals() {
        return ResponseEntity.ok(new ApiResponse<>("Category totals fetched successfully", dashboardService.getCategoryTotals()));
    }

    @GetMapping("/monthly-trend")
    @PreAuthorize("hasAnyRole('ADMIN', 'ANALYST')")
    public ResponseEntity<ApiResponse<List<MonthlyTrendProjection>>> getMonthlyTrend() {
        return ResponseEntity.ok(new ApiResponse<>("Monthly trend fetched successfully", dashboardService.getMonthlyTrend()));
    }
}
