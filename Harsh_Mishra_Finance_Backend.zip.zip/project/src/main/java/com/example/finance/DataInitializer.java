package com.example.finance;

import com.example.finance.model.User;
import com.example.finance.model.enums.Role;
import com.example.finance.model.enums.UserStatus;
import com.example.finance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            String adminPassword = passwordEncoder.encode("admin123");
            User admin = new User("admin@finance.com", adminPassword, Role.ADMIN, UserStatus.ACTIVE);
            userRepository.save(admin);

            String analystPassword = passwordEncoder.encode("analyst123");
            User analyst = new User("analyst@finance.com", analystPassword, Role.ANALYST, UserStatus.ACTIVE);
            userRepository.save(analyst);

            String viewerPassword = passwordEncoder.encode("viewer123");
            User viewer = new User("viewer@finance.com", viewerPassword, Role.VIEWER, UserStatus.ACTIVE);
            userRepository.save(viewer);

            System.out.println("Seeded database with default users:");
            System.out.println("Admin: admin@finance.com / admin123");
            System.out.println("Analyst: analyst@finance.com / analyst123");
            System.out.println("Viewer: viewer@finance.com / viewer123");
        }
    }
}
