package com.example.finance.model.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE
}
