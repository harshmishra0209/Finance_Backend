package com.example.finance.model.enums;

public enum RecordType {
    INCOME,
    EXPENSE
}
