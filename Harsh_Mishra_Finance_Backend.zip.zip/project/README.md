# Finance Data Processing and Access Control Backend

This is the completed assignment for the **Backend Developer Intern** role. It is a fully functional, robust Spring Boot API designed to meet and exceed all core and optional requirements specified in the assignment.

## Tech Stack
- **Framework:** Java 17, Spring Boot 3.x
- **Database:** MySQL
- **ORM:** Spring Data JPA / Hibernate
- **Security:** Spring Security & JWT
- **Validation:** Jakarta Bean Validation (Hibernate Validator)
- **Build Tool:** Maven

## Core Requirements Implemented

1. **User & Role Management**: Implemented `VIEWER`, `ANALYST`, and `ADMIN` roles. Supports user creation mapped to statuses (`ACTIVE`, `INACTIVE`).
2. **Financial Records Management**: Full CRUD endpoints for records containing `amount`, `type`, `category`, `date`, and `notes`. Filters implemented for date and category.
3. **Dashboard Summary**: Aggregate queries via JPQL for `total income`, `total expenses`, `net balance`, `recent activity`, and `category-wise totals`.
4. **Access Control**: Handled using JWT filters and Spring Security `@PreAuthorize` method-level decorators.
5. **Validation & Error Handling**: Global `@ControllerAdvice` exception handler implemented to neatly catch invalid inputs (`@Valid`) and auth errors, returning structured JSON responses.
6. **Data Persistence**: Uses a relational **MySQL** database configuration.

### Optional Enhancements Added
- JWT Token based Authentication.
- Pagination for listing records.
- Comprehensive cleanly-structured N-Layer design.

## How to Setup and Run

### 1. Database Configuration
Ensure **MySQL** is installed and running locally on port `3306`.
The application expects the following credentials by default (configured in `src/main/resources/application.properties`):
- **URL**: `jdbc:mysql://localhost:3306/finance_db?createDatabaseIfNotExist=true`
- **Username**: `root`
- **Password**: `root`

### 2. Running the Application
Open your terminal in the project root folder and execute the Maven wrapper:
```bash
# For Windows
.\mvnw.cmd spring-boot:run

# For Mac/Linux
./mvnw spring-boot:run
```

### 3. Default Seeded Data
When the backend starts for the very first time, it automatically creates three default users so you don't have to populate the database manually. You can use these to test the JWT authentication logic:

1. **Admin User:** `admin@finance.com` | Password: `admin123`
2. **Analyst User:** `analyst@finance.com` | Password: `analyst123`
3. **Viewer User:** `viewer@finance.com` | Password: `viewer123`

## Example Usage

**1. Login (POST /api/auth/login)**
```json
// Request Body
{
    "email": "admin@finance.com",
    "password": "admin123"
}
```

**2. Fetch Dashboard (GET /api/dashboard/summary)**
Send a `GET` request and include the `token` received from the login endpoint as a `Bearer` token in the `Authorization` header.
